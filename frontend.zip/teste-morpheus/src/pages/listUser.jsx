import React from 'react';
import UserList from '../components/userList';

const ListUsers = () => {
    return (
        <div>
            <UserList />
        </div>
    );
};

export default ListUsers;
